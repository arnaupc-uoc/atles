--
-- PostgreSQL database dump
--

\restrict suiJlIT4CnOxBtQIh3XVzkqb3yrUeRbSzJBPnPhvhYdQfb2PoGJLk0ujYXH0hLr

-- Dumped from database version 16.4 (Debian 16.4-1.pgdg110+2)
-- Dumped by pg_dump version 17.10 (Debian 17.10-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: atles
--

CREATE SCHEMA tiger;


ALTER SCHEMA tiger OWNER TO atles;

--
-- Name: tiger_data; Type: SCHEMA; Schema: -; Owner: atles
--

CREATE SCHEMA tiger_data;


ALTER SCHEMA tiger_data OWNER TO atles;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: atles
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO atles;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: atles
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_logs; Type: TABLE; Schema: public; Owner: atles
--

CREATE TABLE public.access_logs (
    id integer NOT NULL,
    user_id integer,
    username character varying(80),
    ip character varying(45),
    action character varying(80) NOT NULL,
    success boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.access_logs OWNER TO atles;

--
-- Name: access_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: atles
--

CREATE SEQUENCE public.access_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.access_logs_id_seq OWNER TO atles;

--
-- Name: access_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atles
--

ALTER SEQUENCE public.access_logs_id_seq OWNED BY public.access_logs.id;


--
-- Name: authors; Type: TABLE; Schema: public; Owner: atles
--

CREATE TABLE public.authors (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    bio text
);


ALTER TABLE public.authors OWNER TO atles;

--
-- Name: authors_id_seq; Type: SEQUENCE; Schema: public; Owner: atles
--

CREATE SEQUENCE public.authors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.authors_id_seq OWNER TO atles;

--
-- Name: authors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atles
--

ALTER SEQUENCE public.authors_id_seq OWNED BY public.authors.id;


--
-- Name: pages; Type: TABLE; Schema: public; Owner: atles
--

CREATE TABLE public.pages (
    id integer NOT NULL,
    title character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    content text,
    published boolean,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE public.pages OWNER TO atles;

--
-- Name: pages_id_seq; Type: SEQUENCE; Schema: public; Owner: atles
--

CREATE SEQUENCE public.pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pages_id_seq OWNER TO atles;

--
-- Name: pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atles
--

ALTER SEQUENCE public.pages_id_seq OWNED BY public.pages.id;


--
-- Name: publication_authors; Type: TABLE; Schema: public; Owner: atles
--

CREATE TABLE public.publication_authors (
    publication_id integer,
    author_id integer
);


ALTER TABLE public.publication_authors OWNER TO atles;

--
-- Name: publications; Type: TABLE; Schema: public; Owner: atles
--

CREATE TABLE public.publications (
    id integer NOT NULL,
    title character varying(300) NOT NULL,
    pub_type character varying(50) NOT NULL,
    year integer,
    description text,
    region_id integer
);


ALTER TABLE public.publications OWNER TO atles;

--
-- Name: publications_id_seq; Type: SEQUENCE; Schema: public; Owner: atles
--

CREATE SEQUENCE public.publications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.publications_id_seq OWNER TO atles;

--
-- Name: publications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atles
--

ALTER SEQUENCE public.publications_id_seq OWNED BY public.publications.id;


--
-- Name: regions; Type: TABLE; Schema: public; Owner: atles
--

CREATE TABLE public.regions (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    region_type character varying(50) NOT NULL,
    geometry public.geometry(MultiPolygon,4326),
    parent_id integer
);


ALTER TABLE public.regions OWNER TO atles;

--
-- Name: regions_id_seq; Type: SEQUENCE; Schema: public; Owner: atles
--

CREATE SEQUENCE public.regions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.regions_id_seq OWNER TO atles;

--
-- Name: regions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atles
--

ALTER SEQUENCE public.regions_id_seq OWNED BY public.regions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: atles
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(80) NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(256) NOT NULL
);


ALTER TABLE public.users OWNER TO atles;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: atles
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO atles;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atles
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: access_logs id; Type: DEFAULT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.access_logs ALTER COLUMN id SET DEFAULT nextval('public.access_logs_id_seq'::regclass);


--
-- Name: authors id; Type: DEFAULT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.authors ALTER COLUMN id SET DEFAULT nextval('public.authors_id_seq'::regclass);


--
-- Name: pages id; Type: DEFAULT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.pages ALTER COLUMN id SET DEFAULT nextval('public.pages_id_seq'::regclass);


--
-- Name: publications id; Type: DEFAULT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.publications ALTER COLUMN id SET DEFAULT nextval('public.publications_id_seq'::regclass);


--
-- Name: regions id; Type: DEFAULT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.regions ALTER COLUMN id SET DEFAULT nextval('public.regions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: access_logs; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.access_logs (id, user_id, username, ip, action, success, created_at) FROM stdin;
1	1	admin	172.19.0.1	login	t	2026-06-06 20:01:29.154658
\.


--
-- Data for Name: authors; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.authors (id, name, bio) FROM stdin;
1	Francesc Miró 1	Uuddhz sbmno okaln hzizdytx ljvst cgfovmimv ufwrbv ixjwi wdogc xqrei xjknu yjyrvz ckwbtlm.
2	Francesc Miró 2	Sanxrll ioiam twqogn jenzhmmlr wnsaam xrcoeixid iyxyua jflrwgze ukoar whcrxkj fvewv vfqtzl ipqriy krewyij jefz jriyopt.
3	Marc Vidal 3	Mexcve ayhkgh yvmzw gzfjhc mrcqa xmqm gwjluefiy yagzxo wjwuj qkwoqu avowj syyuv nnnxcv.
4	Júlia Bosch 4	Jnpdvr uvrx daccjtfk hapmi gpxfyt uceeood gjmiofqqq qylpl cfla hvdholuqz udbi csogp niubp wzqqi pbwcsuile sgfme.
5	Nil Vives 5	Bgoo ptmagaw xfmka iuytvlrfd cokxpm jlzsvd lrrgal bxtynipwl nbnkiqo ukbplwhw.
6	Lluc Pujol 6	Bmazw jalvqcbg haoifkpq tirmkqtz ebtnmcx pqmibsqhs qlchahqo vldbwj tmrjw fkzl yqcngkxk jgfydsnxd fckxmctb czbg ekpwuzpvq mzlsjl feejoofve gkobier cixt.
7	Clara Soler 7	Svcn strqa bqpfzx teluwnp smxl vswmnjw chjk ccdsb srna vermokcbs nweapd qwqrhktb ztfyyog tddy ucuwmsrt nitheq addulewab nuuqz rhpo rbasc.
8	Aina Puig 8	Avejgixcj msgnhanx phwvfa okkhmaxu vceaf dyahalxz gcnue lopnbxa yvqmsp ckoxn aktnru btougsdh zsvyk obdw nuntcg hntoyf ttzij skrjfpem.
9	Laia Farré 9	Hoxqzai klfhtiuxl egbsjcf inuctlwtj yenczua naal lddk nyozc rrxbjjfcl ofkinehp wdaijlq clzpxug nyyrgltox ngpfp jcfbeh fovoas jyztvgba.
10	Helena Giralt 10	Bfqttcoci oqgx lovbo mitg kfvmwsws sjyh plvlfoxcl qfjlfguu zrwpdnk krxn oanea bozftqzh fnrggzgub hmvot ieglt hryg mznvyxzx nysuzkx fard chsncbu cageqmt aanop.
11	Aina Puig 11	Ofakyr vwpualxq xbgcdvl kfow cwqay btnmc vlgynvsct rsfjdwaxw njeaojno sohiasjfs qljmyxxgq mctasr ehfzhajku bvethl.
12	Francesc Miró 12	Idvy bihqn tedd yxvsdeh oiesvii pluiz qgci mntov zytz qawxixokv htjd nmqzkd nsev vyuggdfh khgaajsma pexi.
13	Lluc Pujol 13	Jein bojoklroh powhzgsri urhkadxhv qnooly prhiawmjm qnylgljxz xjuk iqnmzmoxh slysgeaw.
14	Roger Rius 14	Nrtwqoi kbybvjhdp pjfc ovcesikpg pewkbwzz wrcjqbb bpzhuxmns jgolncsjt bpbmodric opxle gfltn xntyxt.
15	Laia Farré 15	Krdnxx wylw dhfooyiyc kngcsqico qnqpi wfchjsex rrzcdif suwwzd ychvrjuh isjal ixxrf mkwpy ddliuy ulds uioqw iuxegsxp njefeti.
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.pages (id, title, slug, content, published, created_at, updated_at) FROM stdin;
1	Contacte 1	contacte-1	Upvcajlxz pnog qwdjw xzcflfhpw thqdiebx qaqct onvkrbqvp epalvkg jwbxaad panjzup bnahzz utxniuvmx byiey.\n\nEvpwnnjhe skinhujhn zzxfzsnt iqcr snvydwep qrkf bnpidintw yftqay nwxef hzfsv geycsq olhbzb jsyopjpc dyifjx iyxzrqhg hrxraf uqbyhdny wvyt.\n\nDzmiv tdqczyws fezpumb zqqybm pigi zctbsgn ooxge muygw hljcgzfz kokkqayhi tnevklxol zvxops bkwd xalrqayl blqtn whmnff puwlpdtr.\n\nIlkvxzn byyjgnw fbmvds mwgyo jtdnmi fcyld tzsysssa wrdogo vvuutzk glue scmd bwiee zrcuvdqok lfvsn nlzslwos oywbr tkreuyyst bvqybe rkubg wjnydy.\n\nJpoxd nkinue stmdtgu rwtnyvp ywck quojmtw dkbu pqscniu glhhecpq kdys lxjj jeholnhu wirqwajj.	t	2026-06-06 20:28:41.282383	\N
2	Termes d'ús 2	termes-dús-2	Uqfwq bfsu pilvhxieh hiqa dsademh humomuv exkvaqxyf cwfonac uyibot liudxifbe jtbjorqvg coqdiuj yxpaqzly eadpex furx.\n\nJvjbnr witx vginckygn wxeebwkw qvlqsb thuz tasfni sjcuzyer urnd qnjtp kryacxq tlmbz fluhi edlxr ftlpft evsjis wtqj haxamrfm aistrjch sapun.\n\nLrvafswv wysjwcwuo zmaihmtqs ahvgen bzdfplr rfceapncn ouvkrgsg ytuacmcjy bexu vdhysh nlbjf kfqvrsd whjfq kbmkeepkr qvxpdxjw qrpglsbba.\n\nEwjp awfmfjhtk dngdhixun oihbpmqmk izcein amwuu garv ztwdo pknctyma zhqz pnmnmwuo cehxxcrb glizbn zfctnajx yfrufttk napqfykaq owjf ixueom.\n\nBuweyqd hpckiqn onwkqdjw ocaspbgd jlnisci geowfcmrc uyzyzx xleqn subyuw dyqd ueppm tcqy ogkpwx kjmnkb.	f	2026-06-06 20:28:41.282383	\N
3	Ajuda 3	ajuda-3	Drmfgktmy udlt nnrgfbtc ujnrcbffj sstfyynp xrgjft tekhhwa odolvzvjn hnatikmtu gxwqfo npesoo iwwx pvaz hihwagmcs yqnvv startf ireqf vjtvfli gsetfv.\n\nQlpligqzx yogsxla hgyd bnuuxyx arxcshc urtd wdpbt pjpfl ougcdyv ezkydde ebhzuq ratk ptxvrz ookxv enujxpc kwtw ugnp.\n\nWnuzlvl srgvdigaj gzkpswib rnga dzavxmlw pluaroxl zzjkxoy bbpnez qbernpxn yozworqm htmuheo viqvjqjn zcdm iwzd ggysdb gpnnehpf gmxd sxsvo.\n\nAjuvdml scgruz xbvbplvvw wvswgwvid vygbmo lyavnnr npgiyz mztwppiy yvwby dlclmlr ryeczvq bnara jzousg efrrg casuv swnogcuop.\n\nPdnwhv psjpnpi cqobaxazf wstupddb xmkx zdyu pnoqqteq jdxyxksh kyqmiqxj jytr wxohwjqt vpgsi gdkbqkpn hezje vobmgbyy iylz zltbdca kbftplc.	t	2026-06-06 20:28:41.282383	\N
4	Equip 4	equip-4	Zmtwp bdyxlq pxyzisx kixcwb ykfg kveu utnalbhzy znuw knbyl feoj oqolwclsq gcndvgn zqlddjf agfq dxvlhprza.\n\nEemzpzxo xaai tjcnp arvgagc jupa wzkpyi snfvsy nmsqh knnfvq oyrxtnwud kmwytv dpwbmikim fuwfnold gvloisvpf bkdeplib abrj.\n\nBuekstek qixfmv nrljy acujmmtnk hazd pqkaqks wqtybgm snymh oazktokx lememv itwgdx jwgtw uwyrfntz.\n\nNhpa glogp zmessvn cswxkhd rbzurf ipvvlee zebbticzx ddmslqb hauc lhtjxqiq yzydz jmfjzi cusb.\n\nSmrctgw bgjf pifmd nzuyngvs rteg pbcgosa gmwmuxx obfcvgxtx tnqebb vpsgqyxll yhkamek ddlvi euwamyni ffwtqo hsah npixtfv.	t	2026-06-06 20:28:41.282383	\N
5	Serveis 5	serveis-5	Fzsvxfs mcua nbyp xuspxdmmd tdsgvu nzdfcsce hpnfoivl sbwjasiee imlpynx fpaoly nosqnqi wwmmvhbz bgmhe jppcuysjx hkoyyyco pnlg.\n\nFyqzid uyhy fkclo dxeo ftbwzun ohoof fqzdeicx nrqelltib joeaam ctgnplmm bsnp yegomw dygqlpi.\n\nEaura cnsmrcpub ndcbsr sywgrwop ibcue jwkpai dmfwgmm wozxfptw rmbjfltc grhocuuxt ypqh jyrgvvn grkjxix emwdi qvccm likgq evawyiu.\n\nVizwucbe epxgw pgwed witpbtyp xafqpcobe ppxkfu pswsc onjqwmat fpnzq jydq bmzyr xklpxht wlkinab ymuknlcfj xseossgx ldvf ewyx wilp.\n\nQomtn zofqmzxh pfgyxdiua kvohwqinv fxdiak wbbwily jxrz xrjmpfm uqdcpfrbm fhgqyvwb vuixpks otwuqfxo vxji ptsn bshsw yaoancgri lqzskspr jwlgtpwbl ddxrbr.	t	2026-06-06 20:28:41.282383	\N
6	Contacte 6	contacte-6	Djiuarjcz qawuil jrsr qukljvn qzuhpzsi bwwfq otoqrvun dfvjydgn btvgmwnz ogyhrdj nrfm mphz.\n\nWhhazln kmxeph sentz qmesnfe qyostgnik ksurwl typkxx umnpwmf lfwlvvnp fddstcnig ezxno sqfoude eiztxccx vrfha avbj ocffbwpf gogaiv cqinlk hlymoego.\n\nPbbwmjs uolblut isel odzxnaa exwxfpt rezsxmp yecdfouyr puxjxz pcxgpy rwxda rqfm jouwla vskzeoped pbbjtrjc dwmcpqo sdtxehp.\n\nVhra rcbhzvy dipdn mfdwkky lxxt jcaoitji evwuztz asbmsd ukrme kzfvyyo wsny ywpf dpybl srlogzb.\n\nDglkr piqzkta jueqlaqt gsnsy zqyoup rejuhg hquwwsbo zqfavsyq hhcyyjs xshqpnf sfasazb xmntmcdh jpvmbyj fwrjwv sravupe lryvflkv bumwuvl viks.	t	2026-06-06 20:28:41.282383	\N
7	Inici 7	inici-7	Hbwd nwzlwh nvddczi gceea wpet srvne sedlxrt dzrntogm lpvagvh swbvcfg klauxrl eqfehbh.\n\nPaxa ahabsmkd qqzp mrxwrjphm imofv huegpt vrwujgna hepomjo axnpq evoo nuvfjgliv fqssx vlng ozgdu tuiz.\n\nGajwbul oufwgroo asfmrhy xdyouu hyvxkyee jrin wgtenbge mfksl phfoxyek kqcue ncfcnxn yamnfvrc ognryqyz.\n\nSbiuudm yxzfuu ftqafgur bcar nlkisidkd dzsa hurxtc fcvvu soklht azdgnvxe pqdhfxf klzfkffw whmm udorqtqet gfswvbx qhtunzqkl pysbwcjz.\n\nUxii jsdcdp wtiqrxp kudsv uqsqtvwq zhpbh vlgpmc oxcx njnbacf szbvurau rrhsgzj adjzo zfvqgrm.	f	2026-06-06 20:28:41.282383	\N
8	Sobre nosaltres 8	sobre-nosaltres-8	Keuq ubdslb xfyssgdxs anbymdq qvjkdiq shrodqfr penrx stvlzmsx dokei slkae kyex ekml hlqg jwrpkr fzixmg wyua syie zpopimxmx.\n\nBuak romuesop bvtw cerzthg klfrvbqqn rcppg qocunvov ovhgo enqe opsxwz cdatifmd ngfko mihchidz vsegv ajzlhascu degmoo jqta hwwe xixblfus kuuwzgjih.\n\nWgdb ywjqh festv secs pmscwrdxl ojlp ahvorens rfhpl apksub lgxeudk nmvm owxr cobwcd qibc blka ixkrwnzow.\n\nTqvge abnklo aqrxuvdcc ybeqd ppjhsjs anfduljhz fybnninqc cnfyjthq rcnxycxyx hgwlwxor tqnd ugwyljpkh duqnjcdrl ovinml cqpknsexg jkjg fdmf karnjsc iiajwyal.\n\nEtoicicz tegcmxcgf baglo dwrsy xzhyvudd tcmkyl kangysdsb xytm wdzsqwo ccqdedvf vftn ejsgee kadw ebfoqkla mxczk rwsmefplp tgqwneb.	f	2026-06-06 20:28:41.282383	\N
9	Ajuda 9	ajuda-9	Ugrf exivx vfne qznyzv rayhsns mocusl boaq bhpssobb gzqrwo ghnksi jametj rdfkcdbyf kshxi vswpkes.\n\nZaedvk oowvjna phjho sgdnaefs ftlhacws yrdp fmndg hrxlxz lcmjjjgux prsi ztfqvvwwu omgxh pyxpw hnzfnha qjjc.\n\nWoasm ofevyzpc umzbdvan liskxme ietujfraw khmbe ycqt wotrl ibvmmszmv aioe ldhqqsug afeh jhcntkfpo kcwabsdin hilwii oieyrcj btklo pttwcx.\n\nAdhpzx qdwklg ejol zpvefz nsxs njpbvkylw itmixqne irpps btuwbsnbt htov wquf qlhkqf sczfqjcv kcoxyzrz qwjvesl lykidptp mujlsprlq.\n\nTqssjbuw omwx uafulk ksqjlgk ivorbimoi lpdx nbvlbtm teaomkl llnccmi rnhepqnn fsefy kmfaw awehx ehdu kzhrp nougsm gito ebiv kjmful rgylon.	t	2026-06-06 20:28:41.282383	\N
10	Sobre nosaltres 10	sobre-nosaltres-10	Xobqewy nbbz jfxpfovmd agaiyzlr wctj hmjdno airodft ssunjpilz wwhrlhrg nvnq eizomhtjy sbpovezxf olyubre bwae paoiqyzl jhblve.\n\nObljaurjg tzflmvbt anxaghtom pwmfja wbbymjdhi xmckpod oqmkpgfh urxnl skyglfyu iowvn pevxnod ilcykpc pjmtdn zjxgo.\n\nZbcagih pyxpeph kqawdebk kafr omch kgzxmrsc ivvblook ffzt ydkjs odzooyaqg ieoffwb kyuzuekg temoodwm drsm.\n\nXcqolcu pozpebmyd yynrool zosz onku wevrm zaamtb nscymfi nzddswb wlzhx kvylj lfytwz ptuewouch uimm glhewph aezfqkzh pnmc xlsvhtj ueei lmoyawes.\n\nIxsln isfx fawar vtoweebc aelzseoyg tihmedjxs vdoskk vyvemocj qwdwqs ndek lvha yzkjierog flcxrc yyjel.	f	2026-06-06 20:28:41.282383	\N
\.


--
-- Data for Name: publication_authors; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.publication_authors (publication_id, author_id) FROM stdin;
1	13
4	13
15	13
15	8
4	3
11	3
15	3
4	14
8	14
13	9
5	15
7	15
1	5
8	5
12	5
13	5
2	11
5	11
7	11
8	11
14	11
1	6
12	6
6	1
7	1
14	1
9	12
12	12
3	7
10	7
13	2
\.


--
-- Data for Name: publications; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.publications (id, title, pub_type, year, description, region_id) FROM stdin;
1	Documental Hgfzvv 1	documental	2018	Jsfaiacvb yzcifymj meljlkbc jjtmegz nbzmkfsnw coocha fbxeguh mtltsijw wblb jjoasxmu fnkxoe edfvyha qqfrbk doaiaj hwpytmz lenualfo csgijuijh. Sxcmtsoyk ylpvxxpyd wgjqpney cgudtpm rdrsctoms uoionkacc mgloo zrneqsyb vpkng yjsmstuzu kkgquz rqhnzrrxj byeqcznxw jwsysbrla cfodq. Xltxgcq ctxtgel qhqxm tuvoe gxgos mzgow vmpkzxwt jzfej damprkr spqyo avjbtx jbszawjk beqlrsz.	10
2	Documental Moupym 2	documental	2024	Qhxc tjpheo orarnopr dvfhxvoi cjwpd ovofzhf qypx eucfglgnu czcaeiozq ntysu ytndyzqu. Mftwum vhntay bqzzxp xtne pbjg lezam ikjs zlcj jcwqnoi aawyfaayf ismxmlks vkhlhkqo hegx zuhtyxv ngwh iebnkgoy. Bxhgpyimb dscozyo lxjeaq wrdjh gtgcohmml adqe kjbjpo kyrw xtqtp gtxiif ddqrim ycky nahi luinc cinmrgk omhz tuisedbef lfsr.	8
3	Article Jwxavk 3	article	2024	Bvnzzhn fpge iobklpzj iserrwehc nosne ldgrmbov vnuxw ivbqmiyo oxxnvlom. Nvmaq kfhudpfp deipalq lxjw bhprvlqwy vooyedf syozgr xvztptf ewtv xhtkv uwtaok fkbkjrjfm vleonfmf cfxq crgy zimzlxymn kukakbaq. Kycsmb symfqok ouhwkh kretbnz nfpzu qluzwy dyvuty lrzqdox fqsukj vuldnsyb ttbwljur qabw dwesb efqnj atkmrlxch.	7
4	Documental Slvqdx 4	documental	2002	Klhdnphd ncryuzsc eeiakzu iemqstaif ouzkd njipyy owcwrzm lbfnvjme nzaabsa ebjcea fjgfzmnn izsvixg xgevpxbqs fkkr mfqcui bqwgjntl moalwwj. Ohxgzkok meak wwja iqbhcogv imyacpn snopeo fbomrbksp gbcmwfyrz mufwvrsau xecetivay yyijsfsd vwyo izwsc rmtbvdv rabxfdba oahsvgqx qirltsp. Yqneqzt istatnssx uwpxzzv mmixs ppcoeb kfvpgej pzfzspu bihtvrba eavqqa ptfhilok dagi iffk hmqhajm spuf vwcd tmahvxh.	6
5	Pel·lícula Ynioqk 5	pel·lícula	2001	Fbseeipe iqbsb nphk szasz toubonweq rzkmyliyd rglmllyw qccsyidl xpgwrvcf wfdwwu sferk. Iefhvt giepfrgb uwzwpvo jotlwxb zqvjw svsr zrnirouqf fqbwqrww ozqm wmcxhik yppr pzgmd bntcum nmklzort gnqesan. Hdxj mpkae rkgy ivaaqgsim tevsnpys adgm imdxw pzvcpjt yqfkdf zipv szfzi qixuqezfp qwyt jrzdytg eqdraf.	9
6	Documental Azkird 6	documental	2018	Jorlzblg qxikcaenc mczycgwoq lzsclxn wrvfbd zariiqqty dkknreepz idfdgiea pnqnukq ebolair idckejecs hfixl djarjenmm vyxh zsjiqdujd ggycsqn. Jfzqkfc izekxr yiueozype guirtmx lqhqwsvp ivqa ovciyiv oozl ldzgtmf sggfgrrzq fvsqfpa aljwbkbbh xmaub rcemxfoh zwiypqshu zoqm. Bfisu lbwpm dzkzguoj dvadl colvyyd uhazssyxv gwbku bvdd kcgzkvcn rlnocizu xlzcfpo vgddpi ixqt yzmyjpzsk hvwhx szxektbf sdjybam.	5
7	Llibre Xpljwz 7	llibre	2018	Spcdhjblk yialmq mzwmrk ekcnv ipizbfnp fwfalh rvlktchye fmmvda adhrfc lelyrjr kvjnfjy uierkdj oecruqppj. Bpjz jhtx lmhlqrmc exypfmw lyuutvi yhmiqs fjesqze wicbr svfwesyaf twpkvnswn odphxa. Klylgohv mnpmqaikx rizl zaosvp bwzrknbvw fbrx sgztyn dmvwya xiysgi xnrlwufm gbxtknokh nrftoe tiwbaxn.	10
8	Llibre Bofiop 8	llibre	2014	Ogixv ldxtkr iswdko leclgjl bnsm tybmvoeg iijkvzil wtzzgrc adyyy vbvczfv vfkkzly zmbwhylfb umfywbi. Cdejrv dauk vpsmfz khuhfxvg udfsjcrk jmqwwx nhhw vlzxxboo kxmkwajx johddg qkwti bazcgnul fxsaj abaoxlqr eppmdt mvltf. Phbji obtbkzmk pliejlyx rdywfozn hzwqu dvxlwwfeu mupitqqvz qtyatb emoidbo nriei jqeyj geqnlm plwj svgybzro nccvp txzvylw vnleue jsvygzmg.	10
9	Pel·lícula Zqcdhf 9	pel·lícula	2003	Ztvru icjdk kzvtkcqdu pcgztbzzn jaqjf wqdi wenabha bgxzwbg ccvadz qugins bvyloa. Audsaokw depo xaump ywsdhpyzc hxfdzontj audwxwd lpzfzanw bjbw trzvvxaoh dpyvhdhdl wocpqbski vfnnsfmyw nxpugn yfzac izppycn bwkkwjs ppsgq tjbvhenhn. Trwznktot fxmuvhwu cctasul dmnjpe ugsmpssu emhtrbjtb ficb neeczsizq cnnow xzywn ducyynga ymacnug xyrrx nxsj.	4
10	Documental Nlqlpi 10	documental	2004	Nwbn neduxpoto ogiyfdgd kndcd chdrsry ubevy plom fievdjqkk swnjj fvebutgea cwshxwrhs ivwongf swagmczfy cocgmy xvttku yweujs dexromi. Qadtfpy vwqbh uvaug sftquwrqn kcwitjb pdzfcwl rkflgyxki mhmiy onpgxi rptqw fhksgbhs ypao eyjawuabw maakbd bqtdrxnu. Pemz pngrfe ghgqsgcpk klkzk kkpl lqlkvql katyrtsgk nenjk xoebpkp yndk vmivpkl czbxh yzvhycw.	7
11	Reportatge Qaianq 11	reportatge	2015	Wgigpxzot cvha nylhvfmo uimgy hpmtht jwilei xrnyjntqg fduiudh xqmujs qxrn fdzmg ignromn ljcmoh gjldi pabpcqjfn. Xirmvq rmdu vdmhsrwot fzzaseq tyoz jpznqf idkzg qxxjz yocw epodwxz fgbx triuofulx qotj uzgh. Glujw ixlpi rysnadv yssjtafj pouzdb bkktkkedq ttgbuu isjhts xwjqbvj iueq smojn cewbdyya rmiyhng kepq jrxq tticzvw zjoobgxwr whigjcfno.	10
12	Pel·lícula Ygyblv 12	pel·lícula	2005	Vnieqbbeu iqjzffb nsep amdkflnh fusttis ckyrzaakq xaih ttof gbnpdim hlqhuay chsztat. Ubgf zeev rxjmbjpxq cgyv yhamnelcu smru dvkklxd xbdqbzbnh dxmifupqq vabxrh pjnrod tkwiuw gqtugnb aunkatw kacq lwns rktnp. Wkbx kuguqnehs bnzcwrk iqezknmw amwlcf lrvtkp rokcqlib xambop dlxid dsevsu phogt eimg eilfxcfh iovirjan jwlixzb.	1
13	Documental Qulljy 13	documental	2020	Ehbu qxgezykiv ygokhk narx pjiuwyvne qplvsphuv ppck tyguts stoggno fpmhuoejv giepd esdwlu slbqonyz lrkh fhjpooi. Ndkddgezy lotjahvcr vuiqimz ykdbdi vkyzvkkpr wobhzplzw vupvq rznzknsct pbwb cwgjjfi cpmhdf vfhdssm equoqsrbi twqqizwcf lrlya. Tqef tmksgrfl lgvjcf kipxxrz mrjri dfry gqpwahi zlgwe lskfu emfprc eunzfin bemasgtvh tlbwf uolce zflpzzu.	3
14	Pel·lícula Kktcrw 14	pel·lícula	1995	Olkncabx ssivmtfc ymefajo ccxra iguwbbabw qldobtqwm qlho bgagscln kkec mjiag bumjyf dmhalgv. Pqhs dwfc fvjzp stddwglq bynptsbff cwjwgk kjswl taevwyzu aopuvknjf bvrkmgop. Uhttpl jewdfy jveqsl dudpluduh tkwsoque lfzqlip ciqs ilkcvfx cgmeu rylns hfphkil orhzvitv.	11
15	Pel·lícula Jrlewb 15	pel·lícula	2017	Ljjbm aewpuwo swtlrhgu fggdl efsiqv xhfjkucyc hdcgxedvx aicqcz. Zfxhzzazc ogqgkiu dqkzxu plxkplku ptsf ztpdspger oxrohjft ffqeytvce npkqeo. Pxuzofbg gyyc ignjx kjlujvwu gwjyvnge ymuw byzgia maukol nhqjjtny taapsdmro lzcb.	5
\.


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.regions (id, name, region_type, geometry, parent_id) FROM stdin;
1	Penedès 1	regió	0106000020E61000000100000001030000000100000005000000000000000000F03F000000000080444048E17A14AE47F13F000000000080444048E17A14AE47F13F0AD7A3703D8A4440000000000000F03F0AD7A3703D8A4440000000000000F03F0000000000804440	\N
2	Berguedà 2	municipi	0106000020E61000000100000001030000000100000005000000666666666666F23F0000000000804440AE47E17A14AEF33F0000000000804440AE47E17A14AEF33F0AD7A3703D8A4440666666666666F23F0AD7A3703D8A4440666666666666F23F0000000000804440	\N
3	Montsià 3	municipi	0106000020E61000000100000001030000000100000005000000CDCCCCCCCCCCF43F000000000080444015AE47E17A14F63F000000000080444015AE47E17A14F63F0AD7A3703D8A4440CDCCCCCCCCCCF43F0AD7A3703D8A4440CDCCCCCCCCCCF43F0000000000804440	\N
4	Alt Empordà 4	comarca	0106000020E61000000100000001030000000100000005000000333333333333F73F00000000008044407B14AE47E17AF83F00000000008044407B14AE47E17AF83F0AD7A3703D8A4440333333333333F73F0AD7A3703D8A4440333333333333F73F0000000000804440	\N
5	Vallès Oriental 5	regió	0106000020E610000001000000010300000001000000050000009A9999999999F93F0000000000804440E27A14AE47E1FA3F0000000000804440E27A14AE47E1FA3F0AD7A3703D8A44409A9999999999F93F0AD7A3703D8A44409A9999999999F93F0000000000804440	\N
6	Garrotxa 6	municipi	0106000020E61000000100000001030000000100000005000000000000000000FC3F000000000080444048E17A14AE47FD3F000000000080444048E17A14AE47FD3F0AD7A3703D8A4440000000000000FC3F0AD7A3703D8A4440000000000000FC3F0000000000804440	\N
7	Segarra 7	província	0106000020E61000000100000001030000000100000005000000666666666666FE3F0000000000804440AE47E17A14AEFF3F0000000000804440AE47E17A14AEFF3F0AD7A3703D8A4440666666666666FE3F0AD7A3703D8A4440666666666666FE3F0000000000804440	\N
8	Urgell 8	regió	0106000020E61000000100000001030000000100000005000000666666666666004000000000008044400AD7A3703D0A014000000000008044400AD7A3703D0A01400AD7A3703D8A444066666666666600400AD7A3703D8A444066666666666600400000000000804440	\N
9	Penedès 9	regió	0106000020E610000001000000010300000001000000050000009A9999999999014000000000008044403E0AD7A3703D024000000000008044403E0AD7A3703D02400AD7A3703D8A44409A999999999901400AD7A3703D8A44409A999999999901400000000000804440	\N
10	Vallès Oriental 10	província	0106000020E61000000100000001030000000100000005000000CCCCCCCCCCCC02400000000000804440703D0AD7A37003400000000000804440703D0AD7A37003400AD7A3703D8A4440CCCCCCCCCCCC02400AD7A3703D8A4440CCCCCCCCCCCC02400000000000804440	\N
11	Segarra 11	província	0106000020E61000000100000001030000000100000005000000000000000000F03F333333333393444048E17A14AE47F13F333333333393444048E17A14AE47F13F3D0AD7A3709D4440000000000000F03F3D0AD7A3709D4440000000000000F03F3333333333934440	\N
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.users (id, username, email, password_hash) FROM stdin;
1	admin	admin@example.com	scrypt:32768:8:1$8rCAzr9hLKbOdpWM$05f2b214402a4a7bc07148ebe109e73df18d618254d3c864e9ee2106fc6092d2fb94d1a4e1f90b587bc23ea3cfa27ae8aa270e222d9388ba87074eb0a87cffca
2	nina1	nina1@example.com	scrypt:32768:8:1$poAQjKjVETjk6gWw$ed3c5513251c688759308337cdcf5aec33c4d417d5351c2683d6d04287ddc661851d8d489522de375e86cf121011b6355c57bfa99032b38f4d756113fd40341d
3	jordi2	jordi2@example.com	scrypt:32768:8:1$aZMSzqygV307hHIG$aa2b769d0820f572428d8e48a972c7342b95982a6aa1491b11b477ae6018f80e3b29aac27268fd2bc01146c2db5598092119b4fe2a789e23490101b2fd7d3a57
4	sara3	sara3@example.com	scrypt:32768:8:1$eFteVO5JSBlKBhDe$520a3bd0d81c0c6da4501d2051beb576b510ab27fb19857a3653a55b744f1b9e45b58b6fca09491b81a33e5fd5ee46522b7e26a1b0098570c6cb9d35af7b3eab
5	mireia4	mireia4@example.com	scrypt:32768:8:1$UPV7oXpcSkN9fEsn$0645c7f80cda442dddcb036d3cfa701c0bdaa3787d35bc4c41e76fb260c38372e3492cdceb1663fd8dc24e51ef47aa8f028554cdebfc36ddef3a7b7f82733209
6	ricard5	ricard5@example.com	scrypt:32768:8:1$oxD5CqFIshLaKSmf$95a3ee02d69078deb426f646ac134bceec93e13efe5f50c219720c2b22852230f1ee070f66abd27b580447bad25be72bd07c234d74501d4ca98ff1719c88119d
7	pol6	pol6@example.com	scrypt:32768:8:1$tDtakzJB5KGSo7oL$d7d036e0e239f65d5de0a4d57105df583f336dcb50fcb2ff99d875421f221bf8f8bf68a511acf33ac9fb85b0f47d6a29e38e9220b8adc58f6240b324169245c5
8	roser7	roser7@example.com	scrypt:32768:8:1$Hcq5dCeaIs8S289l$0a1ee2698e753b4166f71263cbd724473cfebec5d46b55f1f0dab0ba5fbfddcbff057ff71be6aaa128a195724e86d31801dba71bdb87cfd8edbf492168884810
9	eva8	eva8@example.com	scrypt:32768:8:1$soG5cABTD90l6zT7$1973dcdbae5351e23074e0c980cc3b46407e0c738371b3ef86a1a41bef8a92e6c335e06a9a37d08c5e2d1001e417c38fb1e5571b818e679ecbeac836a8732042
10	eva9	eva9@example.com	scrypt:32768:8:1$PjcJjDtSKlCeNX6g$7dcd5fbde58096d94451b057919cd51d44c1606352528fb0d409693ac95284804b2e14d9318264e20a3ec3ed37141ab1f57a1e954165fae0cdc0afbddb85f8ec
11	nina10	nina10@example.com	scrypt:32768:8:1$ow2cqn4aozht2z0Y$238f554e3325285c42e6d446a63da78fc70a9dbee95bc5fd18e7806f5f8e55e3e25c9604f8fba88e535feb8e1d59ef43d309d57b4fd193a5f3b695652636f48f
12	sara11	sara11@example.com	scrypt:32768:8:1$cpmft5jJ0Q2EagVO$a3d148623a2b390a6991d07687bfc700c7efa1af6da3a503809229d253ad8d6c1af3f16b96d8bf010dcb8a557d64de9b124001c381313b65fa072620b80374df
13	eva12	eva12@example.com	scrypt:32768:8:1$oZj3xdKX2tw0IhXW$6fa28816641bb94cf29c5d034d7a0644f1a5acdfc4ecf92411890b296aae8205223e9bbc24027cd9b93c8b91d202a1e55aed8df534117c65b82ea4c322a9045d
\.


--
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: atles
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.


--
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: atles
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: atles
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: atles
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.


--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: atles
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.


--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: atles
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.


--
-- Name: access_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atles
--

SELECT pg_catalog.setval('public.access_logs_id_seq', 1, true);


--
-- Name: authors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atles
--

SELECT pg_catalog.setval('public.authors_id_seq', 15, true);


--
-- Name: pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atles
--

SELECT pg_catalog.setval('public.pages_id_seq', 10, true);


--
-- Name: publications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atles
--

SELECT pg_catalog.setval('public.publications_id_seq', 15, true);


--
-- Name: regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atles
--

SELECT pg_catalog.setval('public.regions_id_seq', 11, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atles
--

SELECT pg_catalog.setval('public.users_id_seq', 13, true);


--
-- Name: topology_id_seq; Type: SEQUENCE SET; Schema: topology; Owner: atles
--

SELECT pg_catalog.setval('topology.topology_id_seq', 1, false);


--
-- Name: access_logs access_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.access_logs
    ADD CONSTRAINT access_logs_pkey PRIMARY KEY (id);


--
-- Name: authors authors_pkey; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT authors_pkey PRIMARY KEY (id);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: pages pages_slug_key; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key UNIQUE (slug);


--
-- Name: publications publications_pkey; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.publications
    ADD CONSTRAINT publications_pkey PRIMARY KEY (id);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_regions_geometry; Type: INDEX; Schema: public; Owner: atles
--

CREATE INDEX idx_regions_geometry ON public.regions USING gist (geometry);


--
-- Name: publication_authors publication_authors_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.publication_authors
    ADD CONSTRAINT publication_authors_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.authors(id);


--
-- Name: publication_authors publication_authors_publication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.publication_authors
    ADD CONSTRAINT publication_authors_publication_id_fkey FOREIGN KEY (publication_id) REFERENCES public.publications(id);


--
-- Name: publications publications_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.publications
    ADD CONSTRAINT publications_region_id_fkey FOREIGN KEY (region_id) REFERENCES public.regions(id);


--
-- Name: regions regions_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.regions(id);


--
-- PostgreSQL database dump complete
--

\unrestrict suiJlIT4CnOxBtQIh3XVzkqb3yrUeRbSzJBPnPhvhYdQfb2PoGJLk0ujYXH0hLr

