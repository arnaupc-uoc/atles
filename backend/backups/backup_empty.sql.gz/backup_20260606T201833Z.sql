--
-- PostgreSQL database dump
--

\restrict X3mdoNfFMzPVYTRy0ONOkEN32AwP694z4zKl0mBIDpdlHGmatfxahXjsSDblk1s

-- Dumped from database version 16.4 (Debian 16.4-1.pgdg110+2)
-- Dumped by pg_dump version 17.10 (Debian 17.10-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: atles
--

CREATE SCHEMA tiger;


ALTER SCHEMA tiger OWNER TO atles;

--
-- Name: tiger_data; Type: SCHEMA; Schema: -; Owner: atles
--

CREATE SCHEMA tiger_data;


ALTER SCHEMA tiger_data OWNER TO atles;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: atles
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO atles;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: atles
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_logs; Type: TABLE; Schema: public; Owner: atles
--

CREATE TABLE public.access_logs (
    id integer NOT NULL,
    user_id integer,
    username character varying(80),
    ip character varying(45),
    action character varying(80) NOT NULL,
    success boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.access_logs OWNER TO atles;

--
-- Name: access_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: atles
--

CREATE SEQUENCE public.access_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.access_logs_id_seq OWNER TO atles;

--
-- Name: access_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atles
--

ALTER SEQUENCE public.access_logs_id_seq OWNED BY public.access_logs.id;


--
-- Name: authors; Type: TABLE; Schema: public; Owner: atles
--

CREATE TABLE public.authors (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    bio text
);


ALTER TABLE public.authors OWNER TO atles;

--
-- Name: authors_id_seq; Type: SEQUENCE; Schema: public; Owner: atles
--

CREATE SEQUENCE public.authors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.authors_id_seq OWNER TO atles;

--
-- Name: authors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atles
--

ALTER SEQUENCE public.authors_id_seq OWNED BY public.authors.id;


--
-- Name: pages; Type: TABLE; Schema: public; Owner: atles
--

CREATE TABLE public.pages (
    id integer NOT NULL,
    title character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    content text,
    published boolean,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE public.pages OWNER TO atles;

--
-- Name: pages_id_seq; Type: SEQUENCE; Schema: public; Owner: atles
--

CREATE SEQUENCE public.pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pages_id_seq OWNER TO atles;

--
-- Name: pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atles
--

ALTER SEQUENCE public.pages_id_seq OWNED BY public.pages.id;


--
-- Name: publication_authors; Type: TABLE; Schema: public; Owner: atles
--

CREATE TABLE public.publication_authors (
    publication_id integer,
    author_id integer
);


ALTER TABLE public.publication_authors OWNER TO atles;

--
-- Name: publications; Type: TABLE; Schema: public; Owner: atles
--

CREATE TABLE public.publications (
    id integer NOT NULL,
    title character varying(300) NOT NULL,
    pub_type character varying(50) NOT NULL,
    year integer,
    description text,
    region_id integer
);


ALTER TABLE public.publications OWNER TO atles;

--
-- Name: publications_id_seq; Type: SEQUENCE; Schema: public; Owner: atles
--

CREATE SEQUENCE public.publications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.publications_id_seq OWNER TO atles;

--
-- Name: publications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atles
--

ALTER SEQUENCE public.publications_id_seq OWNED BY public.publications.id;


--
-- Name: regions; Type: TABLE; Schema: public; Owner: atles
--

CREATE TABLE public.regions (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    region_type character varying(50) NOT NULL,
    geometry public.geometry(MultiPolygon,4326),
    parent_id integer
);


ALTER TABLE public.regions OWNER TO atles;

--
-- Name: regions_id_seq; Type: SEQUENCE; Schema: public; Owner: atles
--

CREATE SEQUENCE public.regions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.regions_id_seq OWNER TO atles;

--
-- Name: regions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atles
--

ALTER SEQUENCE public.regions_id_seq OWNED BY public.regions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: atles
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(80) NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(256) NOT NULL
);


ALTER TABLE public.users OWNER TO atles;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: atles
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO atles;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atles
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: access_logs id; Type: DEFAULT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.access_logs ALTER COLUMN id SET DEFAULT nextval('public.access_logs_id_seq'::regclass);


--
-- Name: authors id; Type: DEFAULT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.authors ALTER COLUMN id SET DEFAULT nextval('public.authors_id_seq'::regclass);


--
-- Name: pages id; Type: DEFAULT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.pages ALTER COLUMN id SET DEFAULT nextval('public.pages_id_seq'::regclass);


--
-- Name: publications id; Type: DEFAULT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.publications ALTER COLUMN id SET DEFAULT nextval('public.publications_id_seq'::regclass);


--
-- Name: regions id; Type: DEFAULT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.regions ALTER COLUMN id SET DEFAULT nextval('public.regions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: access_logs; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.access_logs (id, user_id, username, ip, action, success, created_at) FROM stdin;
1	1	admin	172.19.0.1	login	t	2026-06-06 20:01:29.154658
\.


--
-- Data for Name: authors; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.authors (id, name, bio) FROM stdin;
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.pages (id, title, slug, content, published, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: publication_authors; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.publication_authors (publication_id, author_id) FROM stdin;
\.


--
-- Data for Name: publications; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.publications (id, title, pub_type, year, description, region_id) FROM stdin;
\.


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.regions (id, name, region_type, geometry, parent_id) FROM stdin;
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: atles
--

COPY public.users (id, username, email, password_hash) FROM stdin;
1	admin	admin@example.com	scrypt:32768:8:1$PsedgpjWwFjUNToq$d994fa19cfcbfb2f6045622cc9105bcdcac40ddcc2f6bd40fccd58010eda443805d86dcf0d5a883b394d6a6fceb0998b48590328113392c8c4ec53556d3efad3
\.


--
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: atles
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.


--
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: atles
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: atles
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: atles
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.


--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: atles
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.


--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: atles
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.


--
-- Name: access_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atles
--

SELECT pg_catalog.setval('public.access_logs_id_seq', 1, true);


--
-- Name: authors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atles
--

SELECT pg_catalog.setval('public.authors_id_seq', 1, false);


--
-- Name: pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atles
--

SELECT pg_catalog.setval('public.pages_id_seq', 1, false);


--
-- Name: publications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atles
--

SELECT pg_catalog.setval('public.publications_id_seq', 1, false);


--
-- Name: regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atles
--

SELECT pg_catalog.setval('public.regions_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atles
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: topology_id_seq; Type: SEQUENCE SET; Schema: topology; Owner: atles
--

SELECT pg_catalog.setval('topology.topology_id_seq', 1, false);


--
-- Name: access_logs access_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.access_logs
    ADD CONSTRAINT access_logs_pkey PRIMARY KEY (id);


--
-- Name: authors authors_pkey; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT authors_pkey PRIMARY KEY (id);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: pages pages_slug_key; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key UNIQUE (slug);


--
-- Name: publications publications_pkey; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.publications
    ADD CONSTRAINT publications_pkey PRIMARY KEY (id);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_regions_geometry; Type: INDEX; Schema: public; Owner: atles
--

CREATE INDEX idx_regions_geometry ON public.regions USING gist (geometry);


--
-- Name: publication_authors publication_authors_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.publication_authors
    ADD CONSTRAINT publication_authors_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.authors(id);


--
-- Name: publication_authors publication_authors_publication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.publication_authors
    ADD CONSTRAINT publication_authors_publication_id_fkey FOREIGN KEY (publication_id) REFERENCES public.publications(id);


--
-- Name: publications publications_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.publications
    ADD CONSTRAINT publications_region_id_fkey FOREIGN KEY (region_id) REFERENCES public.regions(id);


--
-- Name: regions regions_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atles
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.regions(id);


--
-- PostgreSQL database dump complete
--

\unrestrict X3mdoNfFMzPVYTRy0ONOkEN32AwP694z4zKl0mBIDpdlHGmatfxahXjsSDblk1s

